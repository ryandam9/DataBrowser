-- Find all Databases in this SQL Server
SELECT *
FROM   sys.databases
WHERE  name NOT IN ('master', 'tempdb', 'model', 'msdb');

-- Find all schemas in a DB
SELECT distinct name
FROM   [db_name].sys.schemas
WHERE  name NOT IN ('db_owner',
                    'db_accessadmin',
                    'db_securityadmin',
                    'db_ddladmin',
                    'db_backupoperator',
                    'db_datareader',
                    'db_datawriter',
                    'db_denydatareader',
                    'db_denydatawriter',
                    'information_schema',
                    'sys'
                   )
ORDER BY 1;					

-- Find all Tables in a database.
SELECT a.table_catalog db,
       a.table_schema  AS schema_name,
       a.table_name,
       a.table_type,
       b.column_name,
       b.data_type,
       b.character_maximum_length,
       b.numeric_precision,
       b.numeric_scale
FROM   [AdventureWorks2].information_schema.tables a,
       [AdventureWorks2].information_schema.columns b
WHERE a.table_catalog = b.table_catalog
  AND a.table_schema = b.table_schema
  AND a.table_name = b.table_name
ORDER BY a.table_catalog, a.table_schema, a.table_type, a.table_name, b.ordinal_position;