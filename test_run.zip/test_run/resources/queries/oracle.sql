-- Print Current DB Name user connected to.
SELECT sys_context('userenv','instance_name') AS db
from dual;

-- Another way
select global_name from global_name;

-- Find all schemas in the current DB
SELECT username as schema_name
FROM   sys.all_users
ORDER BY username;

-- Find all Tables in a database.
SELECT (SELECT name FROM v$database) AS db,
       atc.owner AS schema_name,
       atc.table_name,
       (CASE
          WHEN ao.object_type = 'TABLE' THEN
             'BASE TABLE'
          ELSE
              'VIEW'
       END) AS table_type,
       atc.column_name,
       atc.data_type,
       atc.data_length,
       atc.data_precision,
       atc.data_scale
FROM   all_tab_cols atc,
       all_objects ao
WHERE
  atc.owner NOT IN ('APPQOSSYS', 'CTXSYS', 'DBSNMP', 'DIP', 'OUTLN', 'RDSADMIN', 'SYS', 'SYSTEM')
  AND atc.owner = ao.owner
  AND atc.table_name = ao.object_name
  AND ao.object_type IN ('TABLE', 'VIEW')
ORDER BY db, schema_name, ao.object_type, table_name, atc.column_id

-- Create a User
CREATE USER HR identified BY password;
GRANT CREATE SESSION TO HR;
GRANT UNLIMITED TABLESPACE TO HR;
GRANT CREATE TABLE TO HR;
